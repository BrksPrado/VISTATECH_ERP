import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class entradaScreen extends JPanel {

    public entradaScreen(financeiroScreen parentFrame) {
        setLayout(new BorderLayout());
        setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

        // Painel esquerdo com borda cinza
        JPanel leftPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        leftPanel.setPreferredSize(new Dimension(200, getHeight()));
        leftPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(leftPanel, BorderLayout.WEST);

        // Adicionando campos de texto e botões ao painel esquerdo
        JLabel clienteLabel = new JLabel("NOME DO CLIENTE");
        leftPanel.add(clienteLabel);
        JTextField clienteField = new JTextField();
        leftPanel.add(clienteField);

        JLabel produtoLabel = new JLabel("NOME DO PRODUTO");
        leftPanel.add(produtoLabel);
        JTextField produtoField = new JTextField();
        leftPanel.add(produtoField);

        JLabel valorLabel = new JLabel("VALOR TOTAL DA VENDA");
        leftPanel.add(valorLabel);
        JTextField valorField = new JTextField();
        leftPanel.add(valorField);

        JLabel parcelasLabel = new JLabel("QUANTIDADE DE PARCELAS");
        leftPanel.add(parcelasLabel);
        JTextField parcelasField = new JTextField();
        leftPanel.add(parcelasField);

        JLabel dataLabel = new JLabel("DATA DA VENDA");
        leftPanel.add(dataLabel);
        JTextField dataField = new JTextField();
        leftPanel.add(dataField);

        // Painel central para conteúdo principal
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Controle de Entrada");
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setFont(new Font("Arial Black", Font.PLAIN, 24));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        centerPanel.add(titleLabel);

        // Painel inferior para os botões
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton addButton = new JButton("Adicionar");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Add data handling logic here
            }
        });
        footerPanel.add(addButton);

        JButton clearButton = new JButton("Limpar");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clienteField.setText("");
                produtoField.setText("");
                valorField.setText("");
                parcelasField.setText("");
                dataField.setText("");
            }
        });
        footerPanel.add(clearButton);

        JButton updateButton = new JButton("Atualizar");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Update data handling logic here
            }
        });
        footerPanel.add(updateButton);

        JButton removeButton = new JButton("Remover");
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Remove data handling logic here
            }
        });
        footerPanel.add(removeButton);

        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields(clienteField, produtoField, valorField, parcelasField, dataField)) {
                    parentFrame.showFinanceiroScreen();
                }
            }
        });
        footerPanel.add(okButton);

        JButton cancelButton = new JButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UIManager.put("OptionPane.yesButtonText", "Sim");
                UIManager.put("OptionPane.noButtonText", "Não");
                int response = JOptionPane.showConfirmDialog(
                        parentFrame,
                        "Todas as alterações feitas não serão salvas.\nDeseja continuar?",
                        "",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (response == JOptionPane.YES_OPTION) {
                    parentFrame.showFinanceiroScreen();
                }
            }
        });
        footerPanel.add(cancelButton);

        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
        };
        addButton.addMouseListener(mouseAdapter);
        clearButton.addMouseListener(mouseAdapter);
        updateButton.addMouseListener(mouseAdapter);
        removeButton.addMouseListener(mouseAdapter);
        okButton.addMouseListener(mouseAdapter);
        cancelButton.addMouseListener(mouseAdapter);

        // Adicionando painéis ao painel principal
        add(centerPanel, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);
    }

    private boolean validateFields(JTextField clienteField, JTextField produtoField, JTextField valorField, JTextField parcelasField, JTextField dataField) {
        try {
            String cliente = clienteField.getText();
            String produto = produtoField.getText();
            Double valor = Double.parseDouble(valorField.getText());
            Integer parcelas = Integer.parseInt(parcelasField.getText());
            Date data = new SimpleDateFormat("dd/MM/yyyy").parse(dataField.getText());

            // Additional validation logic can be added here

            return true;
        } catch (NumberFormatException | ParseException e) {
            JOptionPane.showMessageDialog(this, "Por favor, insira valores válidos.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}