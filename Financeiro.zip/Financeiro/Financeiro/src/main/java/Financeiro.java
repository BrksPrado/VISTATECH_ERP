public class Financeiro {
    public static void main(String[] args) {
        financeiroScreen telaPrincipal = new financeiroScreen();
        telaPrincipal.setVisible(true);
    }

}
