package com.vistatech;

import com.vistatech.view.financeiroView;
import com.vistatech.controller.financeiroController;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Garante que a interface rode na thread correta
        SwingUtilities.invokeLater(() -> {
            // Cria a view
            financeiroView view = new financeiroView();

            // Cria o controller passando apenas a view
            new financeiroController(view);

            // Configurações finais da janela
            view.setVisible(true);
            view.setLocationRelativeTo(null); // Centraliza a janela
        });
    }
}