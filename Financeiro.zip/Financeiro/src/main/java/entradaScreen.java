// src/main/java/entradaScreen.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class entradaScreen extends JLabel {

    public entradaScreen(financeiroScreen parentFrame) {
        setLayout(new BorderLayout());

        // Painel central para conteúdo principal
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Controle de Entrada");
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setFont(new Font("Arial Black", Font.PLAIN, 24));
        centerPanel.add(titleLabel);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Painel inferior para os botões
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.showFinanceiroScreen();
            }
        });
        footerPanel.add(okButton);

        JButton cancelButton = new JButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UIManager.put("OptionPane.yesButtonText", "Sim");
                UIManager.put("OptionPane.noButtonText", "Não");
                int response = JOptionPane.showConfirmDialog(
                        parentFrame,
                        "Todas as alterações feitas não serão salvas.\nDeseja continuar?",
                        "",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (response == JOptionPane.YES_OPTION) {
                    parentFrame.showFinanceiroScreen();
                }
            }
        });
        footerPanel.add(cancelButton);

        // Adicionando painéis ao painel principal
        add(centerPanel, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);
    }
}