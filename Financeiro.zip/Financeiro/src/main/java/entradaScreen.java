import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.text.BadLocationException;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class entradaScreen extends JPanel {

    public entradaScreen(financeiroScreen parentFrame) {
        setLayout(new BorderLayout());
        setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

        // Criando o Painel de Título
        JLabel panelTitle = new JLabel("Controle de Entrada");
        panelTitle.setBorder(BorderFactory.createEmptyBorder(10, 400, 0, 0)); // Add padding as needed
        panelTitle.setFont(new Font("Arial Black", Font.PLAIN, 18));
        add(panelTitle, BorderLayout.NORTH);


        // Painel central para conteúdo principal
        JPanel centerPanel = new JPanel();
        centerPanel.setPreferredSize(new Dimension(800, 600)); // Adjust size as needed
        centerPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
        add(centerPanel, BorderLayout.CENTER);

        // Adicionando um JTable ao painel central
        String[] columnNames = {"ID", "Nome do Cliente", "Nome do Produto", "Valor Total", "Parcelas", "Data da Venda"};

        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        JTable table = new JTable(model);
        table.setPreferredScrollableViewportSize(new Dimension(800, 600)); // Adjust size as needed
        table.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
        table.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        table.setBackground(Color.LIGHT_GRAY);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(5,0,0,5));
        scrollPane.setBorder((BorderFactory.createLineBorder(Color.BLACK)));
        centerPanel.add(scrollPane);

        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        for(int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        // Painel esquerdo principal para os campos de entrada e botões
        JPanel leftContainerPanel = new JPanel(new BorderLayout());
        leftContainerPanel.setPreferredSize(new Dimension(400, 300)); // Adjust size as needed
        leftContainerPanel.setBorder(BorderFactory.createEmptyBorder(0,5,0,5)); // Add padding to the left

        // Painel esquerdo para os campos de entrada
        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setPreferredSize(new Dimension(200, 150)); // Set fixed size to make it more square
        leftPanel.setVisible(true);
        leftPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(leftPanel, BorderLayout.WEST);


        // Ajustando o layout do painel esquerdo
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 0, 20, 5); // Add padding as needed

        // Adicionando campos de entrada ao painel esquerdo

        // Label para o nome do cliente
        JLabel clienteLabel = new JLabel("NOME DO CLIENTE:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(clienteLabel, gbc);
        // Campo de texto para o nome do cliente
        JTextField clienteField = new JTextField(15);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.EAST;
        leftPanel.add(clienteField, gbc);

        // Label para o nome do produto
        JLabel produtoLabel = new JLabel("NOME DO PRODUTO:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(produtoLabel, gbc);
        // Campo de texto para o nome do produto
        JTextField produtoField = new JTextField(15);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.EAST;
        leftPanel.add(produtoField, gbc);

        // Label para o valor total da venda
        JLabel valorLabel = new JLabel("VALOR TOTAL DA VENDA:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(valorLabel, gbc);
        // Campo de texto para o valor total da venda
        JTextField valorField = new JTextField(15);
        gbc.gridx = 1;
        leftPanel.add(valorField, gbc);

        // Label para a quantidade de parcelas
        JLabel parcelasLabel = new JLabel("QUANTIDADE DE PARCELAS:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(parcelasLabel, gbc);
        // Campo de texto para a quantidade de parcelas
        JTextField parcelasField = new JTextField(15);
        gbc.gridx = 1;
        leftPanel.add(parcelasField, gbc);



        // Label para a data da venda
        JLabel dataLabel = new JLabel("DATA DA VENDA:");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(dataLabel, gbc);
        // Campo de texto para a data da venda
        JTextField dataField = new JTextField(15);
        gbc.gridx = 1;
        leftPanel.add(dataField, gbc);

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    // Get the values from the selected row and set them to the text fields
                    clienteField.setText(model.getValueAt(selectedRow, 1).toString());
                    produtoField.setText(model.getValueAt(selectedRow, 2).toString());
                    valorField.setText(model.getValueAt(selectedRow, 3).toString());
                    parcelasField.setText(model.getValueAt(selectedRow, 4).toString());
                    dataField.setText(model.getValueAt(selectedRow, 5).toString());
                }
            }
        });


        // Ajustando o tamanho e a fonte das labels
        Font labelSize = new Font("Arial ", Font.BOLD, 12);

        // Setando a fonte das labels
        clienteLabel.setFont(labelSize);
        produtoLabel.setFont(labelSize);
        valorLabel.setFont(labelSize);
        parcelasLabel.setFont(labelSize);
        dataLabel.setFont(labelSize);


        // Painel para os botões
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 5, 5)); // 2 rows, 2 columns, 5px horizontal and vertical gaps
        leftContainerPanel.add(buttonPanel, BorderLayout.NORTH);

        // Botão de adicionar entrada na lista
        JButton addButton = new JButton("Adicionar");
        addButton.setFont(new Font("Arial Black", Font.PLAIN, 18));

        addButton.addActionListener(new ActionListener() {
            private int nextId = 1;

            @Override
            public void actionPerformed(ActionEvent e) {
                String cliente = clienteField.getText();
                String produto = produtoField.getText();
                String valor = valorField.getText();
                String parcelas = parcelasField.getText();
                String data = dataField.getText();

                try {
                    int numParcelas = Integer.parseInt(parcelas);
                    double valorTotal = Double.parseDouble(valor);
                    double valorParcela = valorTotal / numParcelas;
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    Date initialDate = dateFormat.parse(data);

                    Integer id = findExistingId(cliente, produto, valor, parcelas, data);
                    if (id == null) {
                        id = nextId++;
                    }

                    for (int i = 0; i < numParcelas; i++) {
                        String parcelaText = (numParcelas == 1) ? "À Vista" : (i + 1) + "/" + numParcelas;
                        model.addRow(new Object[]{id, cliente, produto, String.format("R$" + "%.2f", valorParcela), parcelaText, dateFormat.format(initialDate)});

                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(initialDate);
                        calendar.add(Calendar.MONTH, 1);
                        initialDate = calendar.getTime();
                    }

                    // Clear the text fields after adding the rows
                    clienteField.setText("");
                    produtoField.setText("");
                    valorField.setText("");
                    parcelasField.setText("");
                    dataField.setText("");
                } catch (ParseException | NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos corretamente.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }

            private Integer findExistingId(String cliente, String produto, String valor, String parcelas, String data) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    if (cliente.equals(model.getValueAt(i, 1)) &&
                            produto.equals(model.getValueAt(i, 2)) &&
                            valor.equals(model.getValueAt(i, 3)) &&
                            parcelas.equals(model.getValueAt(i, 4)) &&
                            data.equals(model.getValueAt(i, 5))) {
                        return (Integer) model.getValueAt(i, 0);
                    }
                }
                return null;
            }
        });

        // Botão de limpar os campos
        JButton clearButton = new JButton("Limpar");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clienteField.setText("");
                produtoField.setText("");
                valorField.setText("");
                parcelasField.setText("");
                dataField.setText("");
            }
        });

        // Botão de atualizar um item da lista
        JButton updateButton = new JButton("Atualizar");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String cliente = clienteField.getText();
                    String produto = produtoField.getText();
                    String valor = valorField.getText();
                    String parcelas = parcelasField.getText();
                    String data = dataField.getText();

                    // Update the selected row in the table model
                    model.setValueAt(cliente, selectedRow, 0);
                    model.setValueAt(produto, selectedRow, 1);
                    model.setValueAt(valor, selectedRow, 2);
                    model.setValueAt(parcelas, selectedRow, 3);
                    model.setValueAt(data, selectedRow, 4);

                    // Clear the text fields after updating the row
                    clienteField.setText("");
                    produtoField.setText("");
                    valorField.setText("");
                    parcelasField.setText("");
                    dataField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecione uma linha para atualizar.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Botão de remover um item da lista
        JButton removeButton = new JButton("Remover");
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    int id = (Integer) model.getValueAt(selectedRow, 0);
                    int choice = JOptionPane.showOptionDialog(null,
                            "Deseja remover todas as parcelas com o mesmo ID ou apenas a selecionada?",
                            "Confirmar Remoção",
                            JOptionPane.YES_NO_CANCEL_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            new String[]{"Todas", "Apenas a Selecionada", "Cancelar"},
                            "Cancelar");

                    if (choice == JOptionPane.YES_OPTION) {
                        // Remove all rows with the same ID
                        for (int i = model.getRowCount() - 1; i >= 0; i--) {
                            if ((Integer) model.getValueAt(i, 0) == id) {
                                model.removeRow(i);
                            }
                        }
                    } else if (choice == JOptionPane.NO_OPTION) {
                        // Remove only the selected row
                        model.removeRow(selectedRow);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecione uma linha para remover.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Ajustando dimensões e cores dos botões
        Dimension buttonSize = new Dimension(230, 60); // Increase button size
        Color buttonColor = new Color(59, 89, 182); // Blue color
        Color foregroundButtonColor = Color.WHITE;
        Font fontButtonSize = new Font("Arial Black", Font.PLAIN, 18);

        // Adionando as mudanças de dimensões e cores aos botões
        addButton.setPreferredSize(buttonSize);
        clearButton.setPreferredSize(buttonSize);
        updateButton.setPreferredSize(buttonSize);
        removeButton.setPreferredSize(buttonSize);

        addButton.setBackground(buttonColor);
        clearButton.setBackground(buttonColor);
        updateButton.setBackground(buttonColor);
        removeButton.setBackground(buttonColor);

        addButton.setForeground(foregroundButtonColor);
        clearButton.setForeground(foregroundButtonColor);
        updateButton.setForeground(foregroundButtonColor);
        removeButton.setForeground(foregroundButtonColor);

        addButton.setFont(fontButtonSize);
        clearButton.setFont(fontButtonSize);
        updateButton.setFont(fontButtonSize);
        removeButton.setFont(fontButtonSize);

        // Adicionando os botões ao painel de botões
        buttonPanel.add(addButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(removeButton);

        // Criando um JSplitPane para dividir o painel esquerdo e o painel de botões
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, leftPanel, buttonPanel);
        splitPane.setResizeWeight(1.0); // Adjust the initial divider location
        leftContainerPanel.add(splitPane, BorderLayout.CENTER);

        // ACABOU A PARTE DO PAINEL ESQUERDO





        // Painel inferior para os botões
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        // Botão de OK
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields(clienteField, produtoField, valorField, parcelasField, dataField)) {
                    parentFrame.showFinanceiroScreen();
                }
            }
        });
        footerPanel.add(okButton);

        // Botão de Cancelar
        JButton cancelButton = new JButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UIManager.put("OptionPane.yesButtonText", "Sim");
                UIManager.put("OptionPane.noButtonText", "Não");
                int response = JOptionPane.showConfirmDialog(
                        parentFrame,
                        "Todas as alterações feitas não serão salvas.\nDeseja continuar?",
                        "",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (response == JOptionPane.YES_OPTION) {
                    parentFrame.showFinanceiroScreen();
                }
            }
        });
        footerPanel.add(cancelButton);

        // Adicionando um mouse listener para mudar o cursor ao passar por cima dos botões
        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
        };
        addButton.addMouseListener(mouseAdapter);
        clearButton.addMouseListener(mouseAdapter);
        updateButton.addMouseListener(mouseAdapter);
        removeButton.addMouseListener(mouseAdapter);

        okButton.addMouseListener(mouseAdapter);
        cancelButton.addMouseListener(mouseAdapter);

        // Adicionando painéis ao painel principal

        add(leftContainerPanel, BorderLayout.WEST);
        add(footerPanel, BorderLayout.SOUTH);
    }

    // Método para validar os campos de entrada
    private boolean validateFields(JTextField clienteField, JTextField produtoField, JTextField valorField, JTextField parcelasField, JTextField dataField) {
        try {
            String cliente = clienteField.getText();
            String produto = produtoField.getText();
            Double valor = Double.parseDouble(valorField.getText());
            Integer parcelas = Integer.parseInt(parcelasField.getText());
            Date data = new SimpleDateFormat("dd/MM/yyyy").parse(dataField.getText());

            // Additional validation logic can be added here

            return true;
        } catch (ParseException | NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Por favor, preencha todos os campos corretamente.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );
            return false;
        }
    }
}