import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class entradaScreen extends JPanel {

    public entradaScreen(financeiroScreen parentFrame) {
        setLayout(new BorderLayout());
        setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

        // Criando o Painel de Título
        JLabel panelTitle = new JLabel("Controle de Entrada");
        panelTitle.setBorder(BorderFactory.createEmptyBorder(10, 400, 0, 0)); // Add padding as needed
        panelTitle.setFont(new Font("Arial Black", Font.PLAIN, 18));
        add(panelTitle, BorderLayout.NORTH);


        // Painel central para conteúdo principal
        JPanel centerPanel = new JPanel();
        centerPanel.setPreferredSize(new Dimension(800, 600)); // Adjust size as needed
        centerPanel.setBorder(BorderFactory.createEmptyBorder(0,10,0,5));
        add(centerPanel, BorderLayout.CENTER);

        // Adicionando um JTable ao painel central
        String[] columnNames = {"Nome do Cliente", "Nome do Produto", "Valor Total", "Parcelas", "Data da Venda"};

        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        JTable table = new JTable(model);
        table.setPreferredScrollableViewportSize(new Dimension(800, 600)); // Adjust size as needed
        table.setFillsViewportHeight(true);
        table.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
        table.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        table.setBackground(Color.LIGHT_GRAY);
        JScrollPane scrollPane = new JScrollPane(table);
        centerPanel.add(scrollPane);

        // Painel esquerdo princiap para os campos de entrada e botões
        JPanel leftContainerPanel = new JPanel(new BorderLayout());
        leftContainerPanel.setPreferredSize(new Dimension(400, 300)); // Adjust size as needed
        leftContainerPanel.setBorder(BorderFactory.createEmptyBorder(0,5,0,5)); // Add padding to the left

        // Painel esquerdo para os campos de entrada
        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setPreferredSize(new Dimension(200, 150)); // Set fixed size to make it more square
        leftPanel.setVisible(true);
        leftPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        add(leftPanel, BorderLayout.WEST);


        // Ajustando o layout do painel esquerdo
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 0, 20, 5); // Add padding as needed

        // Adicionando campos de entrada ao painel esquerdo

        // Label para o nome do cliente
        JLabel clienteLabel = new JLabel("NOME DO CLIENTE:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(clienteLabel, gbc);
        // Campo de texto para o nome do cliente
        JTextField clienteField = new JTextField(15);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.EAST;
        leftPanel.add(clienteField, gbc);

        // Label para o nome do produto
        JLabel produtoLabel = new JLabel("NOME DO PRODUTO:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(produtoLabel, gbc);
        // Campo de texto para o nome do produto
        JTextField produtoField = new JTextField(15);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.EAST;
        leftPanel.add(produtoField, gbc);

        // Label para o valor total da venda
        JLabel valorLabel = new JLabel("VALOR TOTAL DA VENDA:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(valorLabel, gbc);
        // Campo de texto para o valor total da venda
        JTextField valorField = new JTextField(15);
        gbc.gridx = 1;
        leftPanel.add(valorField, gbc);

        // Label para a quantidade de parcelas
        JLabel parcelasLabel = new JLabel("QUANTIDADE DE PARCELAS:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(parcelasLabel, gbc);
        // Campo de texto para a quantidade de parcelas
        JTextField parcelasField = new JTextField(15);
        gbc.gridx = 1;
        leftPanel.add(parcelasField, gbc);

        // Label para a data da venda
        JLabel dataLabel = new JLabel("DATA DA VENDA:");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.WEST;
        leftPanel.add(dataLabel, gbc);
        // Campo de texto para a data da venda
        JTextField dataField = new JTextField(15);
        gbc.gridx = 1;
        leftPanel.add(dataField, gbc);


        // Ajustando o tamanho e a fonte das labels
        Font labelSize = new Font("Arial ", Font.BOLD, 12);

        // Setando a fonte das labels
        clienteLabel.setFont(labelSize);
        produtoLabel.setFont(labelSize);
        valorLabel.setFont(labelSize);
        parcelasLabel.setFont(labelSize);
        dataLabel.setFont(labelSize);



        // Painel para os botões
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 5, 5)); // 2 rows, 2 columns, 5px horizontal and vertical gaps
        leftContainerPanel.add(buttonPanel, BorderLayout.NORTH);

        // Botão de adicionar entrada na lista
        JButton addButton = new JButton("Adicionar");
        addButton.setFont(new Font("Arial Black", Font.PLAIN, 18));
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cliente = clienteField.getText();
                String produto = produtoField.getText();
                String valor = valorField.getText();
                String parcelas = parcelasField.getText();
                String data = dataField.getText();

                // Add a new row to the table model
                model.addRow(new Object[]{cliente, produto, valor, parcelas, data});

                // Clear the text fields after adding the row
                clienteField.setText("");
                produtoField.setText("");
                valorField.setText("");
                parcelasField.setText("");
                dataField.setText("");
            }
        });

        // Botão de limpar os campos
        JButton clearButton = new JButton("Limpar");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clienteField.setText("");
                produtoField.setText("");
                valorField.setText("");
                parcelasField.setText("");
                dataField.setText("");
            }
        });

        // Botão de atualizar um item da lista
        JButton updateButton = new JButton("Atualizar");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String cliente = clienteField.getText();
                    String produto = produtoField.getText();
                    String valor = valorField.getText();
                    String parcelas = parcelasField.getText();
                    String data = dataField.getText();

                    // Update the selected row in the table model
                    model.setValueAt(cliente, selectedRow, 0);
                    model.setValueAt(produto, selectedRow, 1);
                    model.setValueAt(valor, selectedRow, 2);
                    model.setValueAt(parcelas, selectedRow, 3);
                    model.setValueAt(data, selectedRow, 4);

                    // Clear the text fields after updating the row
                    clienteField.setText("");
                    produtoField.setText("");
                    valorField.setText("");
                    parcelasField.setText("");
                    dataField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecione uma linha para atualizar.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Botão de remover um item da lista
        JButton removeButton = new JButton("Remover");
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    // Remove the selected row from the table model
                    model.removeRow(selectedRow);
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, selecione uma linha para remover.", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Ajustando dimensões e cores dos botões
        Dimension buttonSize = new Dimension(230, 60); // Increase button size
        Color buttonColor = new Color(59, 89, 182); // Blue color
        Color foregroundButtonColor = Color.WHITE;
        Font fontButtonSize = new Font("Arial Black", Font.PLAIN, 18);

        // Adionando as mudanças de dimensões e cores aos botões
        addButton.setPreferredSize(buttonSize);
        clearButton.setPreferredSize(buttonSize);
        updateButton.setPreferredSize(buttonSize);
        removeButton.setPreferredSize(buttonSize);

        addButton.setBackground(buttonColor);
        clearButton.setBackground(buttonColor);
        updateButton.setBackground(buttonColor);
        removeButton.setBackground(buttonColor);

        addButton.setForeground(foregroundButtonColor);
        clearButton.setForeground(foregroundButtonColor);
        updateButton.setForeground(foregroundButtonColor);
        removeButton.setForeground(foregroundButtonColor);

        addButton.setFont(fontButtonSize);
        clearButton.setFont(fontButtonSize);
        updateButton.setFont(fontButtonSize);
        removeButton.setFont(fontButtonSize);

        // Adicionando os botões ao painel de botões
        buttonPanel.add(addButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(removeButton);

        // Criando um JSplitPane para dividir o painel esquerdo e o painel de botões
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, leftPanel, buttonPanel);
        splitPane.setResizeWeight(1.0); // Adjust the initial divider location
        leftContainerPanel.add(splitPane, BorderLayout.CENTER);

        // ACABOU A PARTE DO PAINEL ESQUERDO





        // Painel inferior para os botões
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        // Botão de OK
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields(clienteField, produtoField, valorField, parcelasField, dataField)) {
                    parentFrame.showFinanceiroScreen();
                }
            }
        });
        footerPanel.add(okButton);

        // Botão de Cancelar
        JButton cancelButton = new JButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UIManager.put("OptionPane.yesButtonText", "Sim");
                UIManager.put("OptionPane.noButtonText", "Não");
                int response = JOptionPane.showConfirmDialog(
                        parentFrame,
                        "Todas as alterações feitas não serão salvas.\nDeseja continuar?",
                        "",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (response == JOptionPane.YES_OPTION) {
                    parentFrame.showFinanceiroScreen();
                }
            }
        });
        footerPanel.add(cancelButton);

        // Adicionando um mouse listener para mudar o cursor ao passar por cima dos botões
        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
        };
        addButton.addMouseListener(mouseAdapter);
        clearButton.addMouseListener(mouseAdapter);
        updateButton.addMouseListener(mouseAdapter);
        removeButton.addMouseListener(mouseAdapter);

        okButton.addMouseListener(mouseAdapter);
        cancelButton.addMouseListener(mouseAdapter);

        // Adicionando painéis ao painel principal

        add(leftContainerPanel, BorderLayout.WEST);
        add(footerPanel, BorderLayout.SOUTH);
    }

    // Método para validar os campos de entrada
    private boolean validateFields(JTextField clienteField, JTextField produtoField, JTextField valorField, JTextField parcelasField, JTextField dataField) {
        try {
            String cliente = clienteField.getText();
            String produto = produtoField.getText();
            Double valor = Double.parseDouble(valorField.getText());
            Integer parcelas = Integer.parseInt(parcelasField.getText());
            Date data = new SimpleDateFormat("dd/MM/yyyy").parse(dataField.getText());

            // Additional validation logic can be added here

            return true;
        } catch (ParseException | NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Por favor, preencha todos os campos corretamente.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );
            return false;
        }
    }
}