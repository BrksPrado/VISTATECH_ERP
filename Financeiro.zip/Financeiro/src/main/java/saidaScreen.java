// src/main/java/saidaScreen.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class saidaScreen extends JLabel {

    public saidaScreen(financeiroScreen parentFrame) {
        setLayout(new BorderLayout());

        // Central panel for main content
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Controle de Saída");
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setFont(new Font("Arial Black", Font.PLAIN, 24));
        centerPanel.add(titleLabel);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Bottom panel for buttons
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.showFinanceiroScreen();
            }
        });
        footerPanel.add(okButton);

        JButton cancelButton = new JButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UIManager.put("OptionPane.yesButtonText", "Sim");
                UIManager.put("OptionPane.noButtonText", "Não");
                int response = JOptionPane.showConfirmDialog(
                        parentFrame,
                        "Todas as alterações feitas não serão salvas.\nDeseja continuar?",
                        "",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (response == JOptionPane.YES_OPTION) {
                    parentFrame.showFinanceiroScreen();
                }
            }
        });

        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
        };
        okButton.addMouseListener(mouseAdapter);
        cancelButton.addMouseListener(mouseAdapter);

        footerPanel.add(cancelButton);

        // Adding panels to the main panel
        add(centerPanel, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);
    }
}